export const setFilter = (newFilter) => ({
  type: "SET_FILTER",
  payload: newFilter,
});
